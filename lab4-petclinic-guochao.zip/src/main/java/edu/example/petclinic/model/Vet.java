package edu.example.petclinic.model;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.relational.core.mapping.Table;

@Table("vets")
public class Vet extends Person {
	@Autowired
	private Collection<Specialty> specialty;

	public Collection<Specialty> getSpecialty() {
		return specialty;
	}

	public void setSpecialty(Collection<Specialty> specialty) {
		this.specialty = specialty;
	}



}
