package edu.example.petclinic.model;

import org.springframework.data.relational.core.mapping.Table;

@Table("specialties")
public class Specialty extends  NamedEntity{
	
}
