package edu.example.petclinic.model;

public class PetType {

}
