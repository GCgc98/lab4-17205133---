package edu.example.petclinic.model;

import org.springframework.data.relational.core.mapping.Table;

@Table("vet_specialties")
public class VetSpecialty {
	private int specialty_id;
	private int vet_id;
	
	public int getVet_id() {
		return vet_id;
	}
	public void setVet_id(int vet_id) {
		this.vet_id = vet_id;
	}
	public int getSpecialty_id() {
		return specialty_id;
	}
	public void setSpecialty_id(int specialty_id) {
		this.specialty_id = specialty_id;
	}

}
