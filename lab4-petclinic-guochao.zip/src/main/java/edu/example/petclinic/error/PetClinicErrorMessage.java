package edu.example.petclinic.error;

public class PetClinicErrorMessage {
	private int code;
	private String message;
	
	public PetClinicErrorMessage(int code,String message) {
		this.code=code;
		this.message =message;
	}
	
	
	public int getCode() {
		return code;
	}

	public String getMessage() {
		return message;
	}


}
