package edu.example.petclinic.repository;

import java.util.Collection;

import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import edu.example.petclinic.model.Specialty;
import edu.example.petclinic.model.Vet;

@Repository
public interface VetRepository extends CrudRepository<Vet,Integer>{
	@Query("select * from vets where last_name like:condition")
	public Collection<Vet> findByLastName(@Param("condition") String lastName);
	
	@Query("select specialty_id from vet_specialties where vet_id= :condition")
	public Collection<Integer> findVet_SpecialtyById(@Param("condition") int id);
	
	@Query("select * from specialties where id= :condition")
	public Specialty findSpecialtyById(@Param("condition") int id);

}
