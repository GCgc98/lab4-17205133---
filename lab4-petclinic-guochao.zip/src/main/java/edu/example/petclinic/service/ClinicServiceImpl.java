package edu.example.petclinic.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.example.petclinic.model.Owner;
import edu.example.petclinic.model.Pet;
import edu.example.petclinic.model.Specialty;
import edu.example.petclinic.model.Vet;
import edu.example.petclinic.repository.OwnerRepository;
import edu.example.petclinic.repository.VetRepository;

@Service
public class ClinicServiceImpl implements ClinicService{

	@Autowired
	private VetRepository vetRepo;
	private OwnerRepository ownerRepo;


    @Autowired
	public ClinicServiceImpl(
			VetRepository vetRepo,
			OwnerRepository ownerRepo) {
    	this.vetRepo = vetRepo;
    	this.ownerRepo= ownerRepo;
    }
	@Override
    public Collection<Vet> getAllVets() {
		Collection<Vet> vets = new ArrayList<Vet>();
		vetRepo.findAll().forEach(vet ->{
			vet.setSpecialty(getSpecialtys(vet));
			vets.add(vet);
		});
		return vets;
    }
    	
//    	@Override
//    	public Collection<Pet> getAllPets(){
//    	Map<Integer,PetType> map = new HashMap<Integer,PetType>();
//    	petTypeRepo.findAll().forEach(vet->{
//    		map.put(type.getId(,type));
//    	});
//    	Collection<Pet> pets = (Collection<Pet>)petRepo.findAll();
//    	pets.forEach(pet->{
//    		pet.setType(map);
//    	});
//    	return pets;
//    	}
    	
    	
    	@Override
    	public Owner addOwner(Owner owner) {
    		return ownerRepo.save(owner);
    	}
    	
    	@Override
    	public Collection<Owner> getAllOwners(){
    		return (Collection<Owner>)ownerRepo.findAll();
    	}
    	
    	@Override
    	public Collection<Owner> findOwnersByLastName(String lastName){
    		return ownerRepo.findByLastName("%"+lastName+"%");
    	}
		@Override
		public Collection<Pet> getAllPets() {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public Collection<Vet> findVetByLastName(String lastName) {
			// TODO Auto-generated method stub
			return vetRepo.findByLastName("%"+lastName+"%");
		}
		@Override
		public Collection<Specialty> getSpecialtys(Vet vet) {
			Collection<Specialty> specialtys = new ArrayList<Specialty>();
			vetRepo.findVet_SpecialtyById(vet.getId()).forEach(id->{
				Specialty specialty = new Specialty();
				specialty=vetRepo.findSpecialtyById(id);
				specialtys.add(specialty);
			});
			return specialtys;
		}


		@Override
		public Optional<Vet> findvetById(int id) {
			// TODO Auto-generated method stub
			return vetRepo.findById(id);
		}




}