package edu.example.petclinic.service;

import java.util.Collection;
import java.util.Optional;

import edu.example.petclinic.model.Owner;
import edu.example.petclinic.model.Pet;
import edu.example.petclinic.model.Specialty;
import edu.example.petclinic.model.Vet;

public interface ClinicService {
	public Collection<Vet> getAllVets();
	public Collection<Pet> getAllPets();
	public Collection<Owner> getAllOwners();
	public Optional<Vet> findvetById(int id);
	public Collection<Specialty> getSpecialtys(Vet vet);
	public Collection<Owner> findOwnersByLastName(String lastName);
	public Collection<Vet> findVetByLastName(String lastName);
	public Owner addOwner(Owner owner);
	
}
