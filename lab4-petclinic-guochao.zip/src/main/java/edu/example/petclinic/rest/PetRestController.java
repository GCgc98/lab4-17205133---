package edu.example.petclinic.rest;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import edu.example.petclinic.model.Pet;
import edu.example.petclinic.service.ClinicService;

@RestController
@RequestMapping("/api/v1/pets")
public class PetRestController {
	@Autowired
	ClinicService clinicService;
	
//	@RequestMapping(value="",method=RequestMethod.GET,produces="application/json")
//	public ResponseEntity<Collection<Pet>>pets(){
//		Collection<Pet> pets=clinicService.getAllPets();
//		return new ResponseEntity<Colllection<Pet>>(pets,HttpStatus.OK);
//	}
}
